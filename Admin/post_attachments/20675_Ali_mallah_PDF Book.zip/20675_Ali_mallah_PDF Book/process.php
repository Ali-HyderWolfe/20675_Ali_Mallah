<?php
require('fpdf/fpdf.php');

if (isset($_GET['book'])) {
    $bookId = $_GET['book'];
    $books = [
        1 => ["title" => "Atomic Habits", "author" => "James Clear", "content" => "Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life.Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life.Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life.Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life.Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life.Atomic Habits is a guide to breaking bad behaviors and adopting good ones in four steps, showing you how small, incremental, everyday routines compound into massive, positive change over time. The book emphasizes the importance of building systems and how minor improvements can lead to major transformations in your life."],



        2 => ["title" => "48 Laws Of Power", "author" => "Robert Greene", "content" => "The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field.The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field.The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field.The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field.The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field.The 48 Laws of Power is a handbook for those who seek power, observing that it is better to be feared than loved. The book outlines the tactics used by history's great leaders to acquire and maintain power, providing insights into human nature and strategies for navigating power dynamics in any field."],





        3 => ["title" => "Sapiens: A Brief History of Humankind", "author" => "Yuval Noah Harari", "content" => "Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today.Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today.Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today.Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today.Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today.Sapiens explores the history of our species, from the emergence of Homo sapiens in Africa to the present day. Harari discusses how the cognitive revolution, the agricultural revolution, and the unification of humankind under shared myths have shaped our societies and the world we live in today."],




        4 => ["title" => "The Alchemist", "author" => "Paulo Coelho", "content" => "The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom.The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom.The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom.The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom.The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom.The Alchemist tells the mystical story of Santiago, a shepherd boy who dreams of finding a worldly treasure located somewhere in the Egyptian pyramids. The book is a symbolic exploration of following one’s dreams, and the power of believing in oneself, filled with allegory and spiritual wisdom."],




        5 => ["title" => "Thinking, Fast and Slow", "author" => "Daniel Kahneman", "content" => "Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive.Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive.Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive.Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive.Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive.Thinking, Fast and Slow delves into the dual systems that drive the way we think—System 1, which is fast, instinctive, and emotional, and System 2, which is slower, more deliberative, and more logical. Kahneman reveals how these two systems shape our judgments and decisions, often in ways that are counterintuitive."],
    ];

    if (isset($books[$bookId])) {
        $book = $books[$bookId];
        $pdf = new FPDF();
        $pdf->AddPage();

        $pdf->SetFont('Arial', 'B', 20);
        $pdf->Cell(0, 10, $book['title'], 0, 1, 'C');
        $pdf->Ln(10);
        $pdf->SetFont('Arial', 'I', 16);
        $pdf->Cell(0, 10, 'Author: ' . $book['author'], 0, 1, 'C');
        $pdf->Image('images/' . $bookId . '.jpg', 10, 50, 190);
        $pdf->Ln(140);
        $pdf->SetFont('Arial', '', 12);
        $pdf->Cell(0, 10, 'Page 1 of 8', 0, 1, 'C');

for ($i = 2; $i <= 8; $i++) {
    $pdf->AddPage();
    
    $pdf->SetFillColor(135, 206, 250);
    $pdf->Rect(0, 0, 210, 297, 'F');
    
    $pdf->SetDrawColor(0, 0, 0);
    $pdf->Rect(5, 5, 200, 287);
    
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Page ' . $i, 0, 1, 'C');
    $pdf->Ln(10);
    
    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, $book['content']);
    $pdf->Ln(20);
    
    $pdf->Cell(0, 10, 'Page ' . $i . ' of 8', 0, 1, 'C');
}

        $pdf->Output();
    } else {
        echo "Book not found!";
    }
} else {
    echo "No book selected!";
}
?>
