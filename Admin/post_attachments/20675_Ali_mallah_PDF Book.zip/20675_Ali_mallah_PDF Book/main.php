<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Books List</title>
    <style>
        body {
    background: linear-gradient(45deg, blue, black, red);
    background-size: 400% 400%;
    animation: gradientAnimation 15s ease infinite;
}

@keyframes gradientAnimation {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}
        .book-container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 20px;
        }
        .book {
            background-color: black;
            padding: 15px;
            border-radius: 10px;
            width: 200px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            transition: 0.5s;
        }
        .book:hover{
            background-color: red;
            width: 220px;
            -webkit-box-shadow: inset 0px 21px 110px 2px rgba(22,10,255,1);
            -moz-box-shadow: inset 0px 21px 110px 2px rgba(22,10,255,1);
            box-shadow: inset 0px 21px 110px 2px rgba(22,10,255,1);
            transition: 1s;

        }
        .book img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .book h3 {
            font-size: 18px;
            margin: 10px 0;
            color: white;
        }
        .book p {
            font-size: 14px;
            color: #555;
            color: white;
        }
        .book a {
            display: inline-block;
            margin-top: 10px;
            padding: 8px 15px;
            background-color: blue;
            color: #fff;
            text-decoration: none;
            border-radius: 45px;
        }
        .book a:hover {
            background-color: red;
            transition: 0.5s;
        }
        h1 {
            text-align: center;
            margin-top: 20px;
            color: white;
            font-size: 3em;
            font-weight: bold;
            background: linear-gradient(90deg, 
                 rgba(0, 0, 255, 0.3) 0%, 
                 rgba(0, 0, 255, 0.7) 20%, 
                 rgba(0, 0, 255, 0.3) 40%, 
                 rgba(0, 0, 255, 0.7) 60%, 
                 rgba(0, 0, 255, 0.3) 80%, 
                 rgba(0, 0, 255, 0.7) 100%);
            background-size: 200% 100%;
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            animation: neonLights 5s infinite linear;
            }

            @keyframes neonLights {
                0% {
                    background-position: 0 0;
                }
                100% {
                    background-position: 200% 0;
                }
            }
    </style>
</head>
<body>
    <h1>Books Collection</h1>
    <div class="book-container">
        <div class="book">
            <img src="images/1.jpg">
            <h3>Atomic Habits</h3>
            <p>Author: James Clear</p>
            <a href="process.php?book=1">Read Book</a>
        </div>

        <div class="book">
            <img src="images/2.jpg">
            <h3>48 Laws Of Power</h3>
            <p>Author: Robert Greene</p>
            <a href="process.php?book=2">Read Book</a>
        </div>

        <div class="book">
            <img src="images/3.jpg">
            <h3>Sapiens: A Brief History of Humankind</h3>
            <p>Author: Yuval Noah Harari</p>
            <a href="process.php?book=3">Read Book</a>
        </div>

        <div class="book">
            <img src="images/4.jpg">
            <h3>The Alchemist</h3>
            <p>Author: Paulo Coelho</p>
            <a href="process.php?book=4">Read Book</a>
        </div>

        <div class="book">
            <img src="images/5.jpg">
            <h3>Thinking, Fast and Slow</h3>    
            <p>Author:  Daniel Kahneman</p>
            <a href="process.php?book=5">Read Book</a>
        </div>
        
    </div>
</body>
</html>
